<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package progression
 */

get_header(); ?>


<div id="page-title">		
	<div class="width-container">
		<h1><?php _e( 'Oops! That page can&rsquo;t be found.', 'progression' ); ?></h1>
		<?php if(function_exists('bcn_display')) {
				echo '<div id="bread-crumb">';
		        bcn_display();
				echo '</div>';
		}?>
		<div class="clearfix"></div>
	</div>
</div><!-- close #page-title -->


<div class="width-container">
	<div id="full-width-progression">
			<p><?php _e( 'It looks like nothing was found at this location. Maybe try one of the links below or a search?', 'progression' ); ?></p>
			<?php get_search_form(); ?><br>
	<div class="clearfix"></div>
	</div>
</div>

<?php get_footer(); ?>