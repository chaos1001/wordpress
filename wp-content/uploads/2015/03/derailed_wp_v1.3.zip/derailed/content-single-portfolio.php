<?php
/**
 * @package progression
 */
?>
<?php $cc = get_the_content(); if($cc != '') { ?>
<div id="portfolio-single-pro">
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="content-container-pro">
		<?php the_content(); ?>
		<div class="clearfix"></div>
	</div><!-- close .content-container-boxed -->
	<div class="clearfix"></div>
</article><!-- #post-## -->
</div>
<?php } ?>
<div id="eliminate-content-pro"></div>