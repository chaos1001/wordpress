<?php
/**
 * @package progression
 */
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="content-container-pro">
		
		<?php if(has_post_thumbnail()): ?>
			<div class="featured-img-progression">
				<?php if( has_post_format( 'link' ) ): ?><a href="<?php echo get_post_meta($post->ID, 'progression_external_link', true) ?>">
				<?php else: ?><a href="<?php the_permalink(); ?>"><?php endif; ?>
					<?php the_post_thumbnail('progression-portfolio-thumb'); ?>
				</a>
			</div>
		<?php else: ?>
		<?php if( has_post_format( 'gallery' ) ): ?>
			<div class="featured-img-progression">
				<div class="flexslider gallery-progression">
		      	<ul class="slides">
					<?php
					$args = array(
					    'post_type' => 'attachment',
					    'showposts' => '99',
					    'post_status' => null,
					    'post_parent' => $post->ID,
						'orderby' => 'menu_order',
						'order' => 'ASC'
					);
					$attachments = get_posts($args);
					?>
					<?php 
					if($attachments):
					    foreach($attachments as $attachment):
					?>
					<?php $thumbnail = wp_get_attachment_image_src($attachment->ID, 'progression-portfolio-slider'); ?>
					<li><a href="<?php the_permalink(); ?>"><img src="<?php echo $thumbnail[0]; ?>" alt="<?php echo $attachment->post_title; ?>" /></a></li>
					<?php endforeach; endif; ?>
				</ul>
				</div>
			</div>
		<?php else: ?>
			<?php if(get_post_meta($post->ID, 'progression_media_embed', true)): ?>
				<div class="featured-img-progression">
					<?php echo apply_filters('the_content', get_post_meta($post->ID, 'progression_media_embed', true)); ?>
				</div>
			<?php endif; ?> <!-- close media_embed option -->
		<?php endif; ?>	<!-- close post_thumbnail -->
		<?php endif; ?>
		<h4>
			<?php if( has_post_format( 'link' ) ): ?><a href="<?php echo get_post_meta($post->ID, 'progression_external_link', true) ?>">
			<?php else: ?><a href="<?php the_permalink(); ?>"><?php endif; ?>
			<?php the_title(); ?>
			</a>
		</h4>
		
		<div class="meta-progression-port"><?php _e( 'Posted in', 'progression' ); ?> <ul><?php $terms = get_the_terms( $post->ID , 'portfolio_type' ); 
        foreach ( $terms as $term ) {
            $term_link = get_term_link( $term, 'portfolio_type' );
            if( is_wp_error( $term_link ) )
            continue;
        	echo '<li><a href="' . $term_link . '">' . $term->name . '</a> <i class="fa fa-asterisk"></i> </li>';
        } 
    ?></ul></div>

		
		<div class="clearfix"></div>
	</div>
</article><!-- #post-## -->