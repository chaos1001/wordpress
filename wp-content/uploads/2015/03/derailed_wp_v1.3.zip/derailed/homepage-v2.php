<?php
// Template Name: HomePage v2
/**
 *
 * @package progression
 * @since progression 1.0
 */

get_header(); ?>
	
<?php get_template_part( 'slider-v2', 'progression' ); ?>

	<!-- this code pull in the homepage content -->
	<?php while(have_posts()): the_post(); ?>
		<?php $cc = get_the_content(); if($cc != '') { ?>
		<div id="home-content-pro">
			<div class="width-container">
				<div class="content-container-pro">
					<?php the_content(); ?>
					<div class="clearfix"></div>
				</div><!-- close .content-container-boxed -->
			</div>
		</div>
	<?php } ?>
	<?php endwhile; ?>
	
	
	<!-- display homepage widgets -->
	<?php if ( is_active_sidebar( 'homepage-widgets' ) ) : ?>
		<?php dynamic_sidebar( 'homepage-widgets' ); ?>
	<?php endif; ?>

<?php get_footer(); ?>