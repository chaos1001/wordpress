<div id="sidebar">
	<?php if ( ! dynamic_sidebar( 'sidebar-shop' ) ) : ?>
	<?php endif; // end sidebar widget area ?>
</div><!-- close #sidebar -->