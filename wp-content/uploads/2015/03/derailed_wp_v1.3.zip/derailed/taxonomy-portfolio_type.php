<?php
/**
 * The template for displaying Archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package progression
 */

get_header(); ?>

<div id="page-title">		
	<div class="width-container">
		<h1><?php if (is_tax('portfolio_type')) {
					$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
					$tax_term_breadcrumb_taxonomy_slug = $term->taxonomy;
					echo '' . $term->name . '';
				}
				?></h1>
		<?php if(function_exists('bcn_display')) {
				echo '<div id="bread-crumb">';
		        bcn_display();
				echo '</div>';
		}?>
		<div class="clearfix"></div>
	</div>
</div><!-- close #page-title -->


<div class="width-container">

	<?php if ( have_posts() ) : ?>		
		<ul id="portfolio-sub-nav">
			<?php echo progression_portfolio_category_nav(); ?>
		</ul>	

		<div id="portfolio-cat-description"><?php echo category_description( ); ?></div>	
		
		
		<div id="mason-layout" class="transitions-enabled fluid">
			<?php
			/* Start the Loop */
			?>
			<?php while ( have_posts() ) : the_post();
				$col_count_progression = get_theme_mod('portfolio_col_progression', '2');
			?>
			<div class="boxed-mason col<?php echo get_theme_mod('portfolio_col_progression', '2'); ?>">
				<?php
					get_template_part( 'content', 'portfolio');
				?>
			</div>

			<?php endwhile; ?>


			<script>
			jQuery(document).ready(function($) {
				
				var $container = $('#mason-layout');
				$container.imagesLoaded(function(){
				  $container.masonry({
				    itemSelector : '.boxed-mason'
				  });
				});
		
			    $('#mason-layout').masonry({
			      itemSelector: '.boxed-mason',
			      // set columnWidth a fraction of the container width
			      columnWidth: function( containerWidth ) {
			        return containerWidth / <?php echo get_theme_mod('portfolio_col_progression', '2'); ?>;
			      }
	
			    });
				
			});

			</script>
			
		</div><!-- close #mason-layout-pro -->

			<div class="clearfix"></div>
			<?php show_pagination_links( ); ?>

	<?php else : ?>

		<div class="width-container">
			<div id="content-container">

				<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
					<div class="content-container-pro">
						<br>
						<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>

							<p><?php printf( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'progression' ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>

						<?php elseif ( is_search() ) : ?>

							<p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'progression' ); ?></p>
							<?php get_search_form(); ?>

						<?php else : ?>

							<p><?php _e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'progression' ); ?></p>
							<?php get_search_form(); ?>

						<?php endif; ?>
						<br><br>
					</div>
				</article>

			</div>
	
			<?php get_sidebar(); ?>
			<div class="clearfix"></div>
		</div>

	<?php endif; ?>

<div class="clearfix"></div>
</div><!-- close .width-container -->
<?php get_footer(); ?>