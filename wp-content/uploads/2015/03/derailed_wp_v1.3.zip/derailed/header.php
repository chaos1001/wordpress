<?php
/**
 * The Header for our theme.
 *
 * @package progression
 * @since progression 1.0
 */
?><!doctype html>
<!--[if lt IE 7]> <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]> <html class="no-js lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>  <html class="no-js lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" <?php language_attributes(); ?>> <!--<![endif]-->
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">

	<title><?php wp_title( '|', true, 'right' ); ?></title>
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<header>
	<div class="width-container">
		<h1 id="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php echo get_theme_mod( 'logo_upload', get_template_directory_uri() . '/images/logo.png' ); ?>" alt="<?php bloginfo('name'); ?>" width="<?php echo get_theme_mod( 'logo_width', '157' ); ?>" /></a></h1>
		<nav>
			<?php wp_nav_menu( array('theme_location' => 'primary', 'depth' => 4, 'menu_class' => 'sf-menu') ); ?>
		</nav>
		<div class="social-ico">
			<?php if (get_theme_mod( 'facebook_link_progression' )) : ?><a href="<?php echo get_theme_mod('facebook_link_progression'); ?>" target="_blank"><i class="fa fa-facebook"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'twitter_link_progression' )) : ?><a href="<?php echo get_theme_mod('twitter_link_progression'); ?>" target="_blank"><i class="fa fa-twitter"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'google_link_progression' )) : ?><a href="<?php echo get_theme_mod('google_link_progression'); ?>" target="_blank"><i class="fa fa-google-plus"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'linkedin_link_progression' )) : ?><a href="<?php echo get_theme_mod('linkedin_link_progression'); ?>" target="_blank"><i class="fa fa-linkedin"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'instagram_link_progression' )) : ?><a href="<?php echo get_theme_mod('instagram_link_progression'); ?>" target="_blank"><i class="fa fa-instagram"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'pinterest_link_progression' )) : ?><a href="<?php echo get_theme_mod('pinterest_link_progression'); ?>" target="_blank"><i class="fa fa-pinterest"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'tumblr_link_progression' )) : ?><a href="<?php echo get_theme_mod('tumblr_link_progression'); ?>" target="_blank"><i class="fa fa-tumblr"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'youtube_link_progression' )) : ?><a href="<?php echo get_theme_mod('youtube_link_progression'); ?>" target="_blank"><i class="fa fa-youtube-play"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'dropbox_link_progression' )) : ?><a href="<?php echo get_theme_mod('dropbox_link_progression'); ?>" target="_blank"><i class="fa fa-dropbox"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'flickr_link_progression' )) : ?><a href="<?php echo get_theme_mod('flickr_link_progression'); ?>" target="_blank"><i class="fa fa-flickr"></i></a><?php endif; ?>
			<?php if (get_theme_mod( 'dribbble_link_progression' )) : ?><a href="<?php echo get_theme_mod('dribbble_link_progression'); ?>" target="_blank"><i class="fa fa-dribbble"></i></a><?php endif; ?>
		</div>
	<div class="clearfix"></div>
	</div><!-- close .width-container -->
</header>

<div id="main">