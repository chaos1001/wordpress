<?php
get_template_part('widgets/flickr-widget');
get_template_part('widgets/latest-blog-posts');
get_template_part('widgets/latest-portfolio-posts');
get_template_part('widgets/product-posts');
?>