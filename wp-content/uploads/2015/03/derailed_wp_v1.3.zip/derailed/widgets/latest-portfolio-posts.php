<?php
add_action('widgets_init', 'pyre_homepage_portfolio_load_widgets');

function pyre_homepage_portfolio_load_widgets()
{
	register_widget('Pyre_Latest_Portfolio_Media_Widget');
}

class Pyre_Latest_Portfolio_Media_Widget extends WP_Widget {
	
	function Pyre_Latest_Portfolio_Media_Widget()
	{
		$widget_ops = array('classname' => 'pyre_homepage_media-port', 'description' => 'Latest Portfolio Posts');

		$control_ops = array('id_base' => 'pyre_homepage_media-widget-port');

		$this->WP_Widget('pyre_homepage_media-widget-port', 'Progression Home: Portfolio Posts ', $widget_ops, $control_ops);
	}
	
	function widget($args, $instance)
	{
		global $post;
		
		extract($args);
		
		$title = apply_filters('widget_title', $instance['title']);
		$portfolioslug = $instance['portfolioslug'];
		
		echo $before_widget;
	 ?>
	 	

	<?php if($title): ?>
		<div class="width-container">
			<h3 class="home-widget-portfolio"><?php echo $title; ?></h3>
		</div>
	<?php endif; ?>
		
		<?php		
		if ( get_query_var('paged') ) {
		    $paged = get_query_var('paged');
		} else if ( get_query_var('page') ) {
		    $paged = get_query_var('page');
		} else {
		    $paged = 1;
		}
		$args = array(
			'paged' => $paged,
		    'tax_query'      => array(
		        // Note: tax_query expects an array of arrays!
		        array(
		            'taxonomy' => 'portfolio_type', // my guess
		            'field'    => 'slug',
		            'terms'    => $portfolioslug
		        )
		    ),
		);
		query_posts($args);
		?>
		
		<div class="width-container fix-margin-pro">
		<div id="mason-layout" class="transitions-enabled fluid">
		<?php if ( have_posts() ) : while ( have_posts() ) : the_post();
			$col_count_progression = get_theme_mod('portfolio_col_progression', '2');
		?>
			<div class="boxed-mason col<?php echo get_theme_mod('portfolio_col_progression', '2'); ?>">
				<?php
					get_template_part( 'content', 'portfolio');
				?>
			</div>
		<?php endwhile; ?>
		<script>
		jQuery(document).ready(function($) {
			var $container = $('#mason-layout');
			$container.imagesLoaded(function(){
			  $container.masonry({
			    itemSelector : '.boxed-mason'
			  });
			});
		    $('#mason-layout').masonry({
		      itemSelector: '.boxed-mason',
		      // set columnWidth a fraction of the container width
		      columnWidth: function( containerWidth ) {
		        return containerWidth / <?php echo get_theme_mod('portfolio_col_progression', '2'); ?>;
		      }

		    });
		});
		</script>
		</div><!-- close #mason-layout-pro -->
		<div class="clearfix"></div>
		<?php show_pagination_links( ); ?>
		</div><!-- close .width-container -->
	
		<?php endif; ?>
		<?php wp_reset_query(); ?>
			
		<?php
		echo $after_widget;
	}
	
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		$instance['portfolioslug'] = $new_instance['portfolioslug'];
		
		return $instance;
	}

	function form($instance)
	{
		
		$defaults = array('title' => 'Our Gallery', 'portfolioslug' => 'featured');
		$instance = wp_parse_args((array) $instance, $defaults); ?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>">Title:</label>
			<input class="widefat" style="width: 216px;" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		
		<p>
			<label for="<?php echo $this->get_field_id('portfolioslug'); ?>">Portfolio Category Slug:</label>
			<input class="widefat" style="width: 216px;" id="<?php echo $this->get_field_id('portfolioslug'); ?>" name="<?php echo $this->get_field_name('portfolioslug'); ?>" value="<?php echo $instance['portfolioslug']; ?>" />
		</p>
		

		
	<?php }
}
?>