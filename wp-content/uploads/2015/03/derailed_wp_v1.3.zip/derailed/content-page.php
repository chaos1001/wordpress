<?php
/**
 * The template used for displaying page content in page.php
 *
 * @package progression
 */
?>

<div id="content-container">
	<div class="content-container-pro">
		<?php if(get_post_meta($post->ID, 'pageoptions_contact_map', true)): ?>
			<div class="featured-img-progression">
				<?php echo apply_filters('the_content', get_post_meta($post->ID, 'pageoptions_contact_map', true)); ?>
			</div><!-- close #main-image-pro -->
		<?php endif; ?>
		
		<?php if(has_post_thumbnail()): ?>
			<div class="featured-img-progression">
				<?php the_post_thumbnail('progression-blog'); ?>
			</div>
		<?php endif; ?>
		<?php the_content(); ?>
		<?php
			wp_link_pages( array(
				'before' => '<div class="page-links">' . __( 'Pages:', 'progression' ),
				'after'  => '</div>',
			) );
		?>
		<?php edit_post_link( __( 'Edit', 'progression' ), '<p class="edit-link">', '</p>' ); ?>
		<?php
			// If comments are open or we have at least one comment, load up the comment template
			if ( comments_open() || '0' != get_comments_number() )
				comments_template();
		?>
	</div><!-- close .content-container-pro -->
</div>