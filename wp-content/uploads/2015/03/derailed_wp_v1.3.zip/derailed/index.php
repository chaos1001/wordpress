<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package progression
 */

get_header(); ?>



<?php if ( have_posts() ) : ?>
	
<div id="page-title">		
	<div class="width-container">
		<?php $page_for_posts = get_option('page_for_posts'); ?>
		<h1><?php echo get_the_title($page_for_posts); ?></h1>
		<?php if(function_exists('bcn_display')) {
				echo '<div id="bread-crumb">';
		        bcn_display();
				echo '</div>';
		}?>
		<div class="clearfix"></div>
	</div>
</div><!-- close #page-title -->


<div class="width-container">
	<div id="content-container">
		<?php /* Start the Loop */ ?>
		<?php while ( have_posts() ) : the_post(); ?>

			<?php
				/* Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'content', get_post_format() );
			?>

		<?php endwhile; ?>

		<?php show_pagination_links( ); ?>

	<?php else : ?>

		<?php get_template_part( 'no-results', 'index' ); ?>

	<?php endif; ?>
	</div>
	
	<?php get_sidebar(); ?>
	<div class="clearfix"></div>
</div>

<?php get_footer(); ?>