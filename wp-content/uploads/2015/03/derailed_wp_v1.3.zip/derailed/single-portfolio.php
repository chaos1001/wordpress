<?php
/**
 * The Template for displaying all single posts.
 *
 * @package progression
 */

get_header(); ?>


<div id="page-title">		
	<div class="width-container">
		<h1>
			<?php the_title(); ?>
			<!--?php 
			$terms = get_the_terms($post->ID, 'portfolio_type' );
			if ($terms && ! is_wp_error($terms)) :
				$term_slugs_arr = array();
				foreach ($terms as $term) {
				    $term_slugs_arr[] = $term->slug;
				}
				$terms_slug_str = join( ", ", $term_slugs_arr);
			endif;
			echo $terms_slug_str;
				?--></h1>
				<?php if(function_exists('bcn_display')) {
						echo '<div id="bread-crumb">';
				        bcn_display();
						echo '</div>';
				}?>
		<div class="clearfix"></div>
	</div>
</div><!-- close #page-title -->

<?php if(get_post_meta($post->ID, 'progression_media_embed', true)): ?>
	<div id="main-image-pro">
		<div class="width-container">
			<?php echo apply_filters('the_content', get_post_meta($post->ID, 'progression_media_embed', true)); ?>
		</div>
	</div>
<?php else: ?>
<?php if( has_post_format( 'gallery' ) ): ?>
	<div id="main-image-pro">
		<div id="portfolio-slider-pro">
			<div id="pro_slider" class="flexslider">
	      	<ul class="slides">
				<?php
				$args = array(
				    'post_type' => 'attachment',
				    'numberposts' => '-1',
				    'post_status' => null,
				    'post_parent' => $post->ID,
					'orderby' => 'menu_order',
					'order' => 'ASC'
				);
				$attachments = get_posts($args);
				?>
				<?php 
				if($attachments):
				    foreach($attachments as $attachment):
				?>
				<?php $thumbnail = wp_get_attachment_image_src($attachment->ID, 'progression-portfolio-single'); ?>
				<?php $image = wp_get_attachment_image_src($attachment->ID, 'large'); ?>
				<li>
					<a href="<?php echo $image[0]; ?>" rel="prettyPhoto[pp_gal]"><img src="<?php echo $thumbnail[0]; ?>" alt="<?php echo $attachment->post_title; ?>"></a>
					
					
					<?php if($attachment->post_excerpt): ?>
					<div class="caption-progression">
						<div class="width-container">
							<h2>
								<?php if($attachment->post_content): ?><a href="<?php echo $attachment->post_content; ?>"><?php endif; ?>
									<?php echo $attachment->post_excerpt; ?>
								<?php if($attachment->post_content): ?></a><?php endif; ?>
							</h2>
						</div>
					</div><!-- close .caption-progression -->
					<?php endif; ?>
				</li>
				<?php endforeach; endif; ?>
			</ul>
			</div>
			
			<div id="carousel-pro" class="flexslider"><ul class="slides">
	      	<ul class="slides">
				<?php 
				if($attachments):
				    foreach($attachments as $attachment):
				?>
				<?php $thumbnail2 = wp_get_attachment_image_src($attachment->ID, 'progression-slider-thumb'); ?>
				<li><img src="<?php echo $thumbnail2[0]; ?>" alt="<?php echo $attachment->post_title; ?>" /></li>
				<?php endforeach; endif; ?>
			</ul>
			</div>
			
		<div class="clearfix"></div>
		</div>
	</div>
<?php else: ?>
	<?php if(has_post_thumbnail()): ?>
	<div id="main-image-pro">
		<div class="feature-single-pro">
			<?php $image = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID), 'large'); ?>
			<a href="<?php echo $image[0]; ?>" rel="prettyPhoto">
				<?php the_post_thumbnail('progression-portfolio-single'); ?>
				
				
				<?php if(get_post(get_post_thumbnail_id())->post_excerpt): ?>
				<div class="caption-progression">
					<div class="width-container">
						<h2>
							
							<?php if(get_post(get_post_thumbnail_id())->post_content): ?><a href="<?php echo get_post(get_post_thumbnail_id())->post_content; ?>"><?php endif; ?>
								<?php echo get_post(get_post_thumbnail_id())->post_excerpt; ?>
							<?php if(get_post(get_post_thumbnail_id())->post_content): ?></a><?php endif; ?>
						</h2>
					</div>
				</div><!-- close .caption-progression -->
				<?php endif; ?>
			</a>
		</div>
	</div><!-- close #main-image-pro -->
	<?php endif; ?>
<?php endif; ?>
<?php endif; ?> <!-- close media_embed option -->
<div class="width-container">
	<?php while ( have_posts() ) : the_post(); ?>
		
		<?php get_template_part( 'content', 'single-portfolio' ); ?>
		
	<?php endwhile; // end of the loop. ?>
	<div class="clearfix"></div>
</div>
<?php get_footer(); ?>
